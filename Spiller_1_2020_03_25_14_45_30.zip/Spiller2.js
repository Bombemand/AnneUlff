class Spiller2 {
  constructor() {
    this.x = (width/15)/2;
    this.y = (height/15)/2;
    
  }

  
  update() {
    
    //____________________________________________________________
    if (keyIsDown('65')) {
      this.x -= 5;
    }

    if (keyIsDown('68')) {
      this.x += 5;
    }

    if (this.x > width - spillertyk*0.5) {
      this.x = width - (spillertyk*0.5);
    }

    if (this.x < spillertyk/2){
    this.x = spillertyk/2;
    }
    //____________________________________________________________
      
         if (keyIsDown('87')) {
      this.y -= 5;
    }

    if (keyIsDown('83')) {
      this.y += 5;
    }

    if (this.y > height - spillertyk*0.5) {
      this.y = height - (spillertyk*0.5);
    }

    if (this.y < spillertyk/2){
    this.y = spillertyk/2;
    }
      
      
    }
    
  
  show() {
    //Figur
    fill(158, 117, 243);
    noStroke();
    circle(this.x,this.y, spillertyk);
    
  }

}



