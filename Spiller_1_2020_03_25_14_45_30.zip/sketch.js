let spillertyk;



function setup() {
  createCanvas(600, 600);
  spillertyk = (width/15)/1.5;
  player1 = new Spiller1();
  player2 = new Spiller2();
}

function draw() {
  background(70);
  
  player1.show();
  player1.update();
  
  player2.show();
  player2.update();
  
}




