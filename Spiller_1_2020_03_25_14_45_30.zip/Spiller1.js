class Spiller1 {
  constructor() {
    this.x = (width/15)*15-(width/15)/2;
    this.y = (height/15)*15-(height/15)/2;
  }

  
  update() {
    
    //____________________________________________________________
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 5;
    }

    if (keyIsDown(RIGHT_ARROW)) {
      this.x += 5;
    }

    if (this.x > width - spillertyk*0.5) {
      this.x = width - (spillertyk*0.5);
    }

    if (this.x < spillertyk/2){
    this.x = spillertyk/2;
    }
    //____________________________________________________________
      
         if (keyIsDown(UP_ARROW)) {
      this.y -= 5;
    }

    if (keyIsDown(DOWN_ARROW)) {
      this.y += 5;
    }

    if (this.y > height - spillertyk*0.5) {
      this.y = height - (spillertyk*0.5);
    }

    if (this.y < spillertyk/2){
    this.y = spillertyk/2;
    }
      
      
    }
    
  
  show() {
    //Figur
    fill(255, 217, 229);
    noStroke();
    circle(this.x,this.y, spillertyk);
    
  }

}
