function makeBoard(cols,rows) {
  let array = new Array(cols);
  for(let i = 0; i < array.length; i++) {
    array[i] = new Array(rows);
  }
  return array;
}

let board,w;
const cols = 15, rows = 15;

function setup() {
  createCanvas(900, 900);
  board = makeBoard(cols, rows);
  w = floor(width / cols);
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      board[i][j] = new Cell(i,j,w,null,null);
  }
  }
}

function draw() {
  background(220);
   for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      board[i][j].draw();
  }
  }
}

function Cell(i,j,w,state,type) {
  this.i = i;
  this.j = j;
  this.x = i * w;
  this.y = j * w;
  this.w = w;
  this.state = state;
  this.type = type;
  
  //de sorte og hvide felter
  this.draw = () => {
    if (this.i % 2 && this.j % 2) {
    fill(0);
    } else {
      fill(255);
    }
    rect(this.x, this.y, this.w, this.w);
  }
}