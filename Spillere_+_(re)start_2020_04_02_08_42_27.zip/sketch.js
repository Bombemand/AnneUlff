let spillertyk;
let start = 0;
let liv1 = 0;
let liv2 = 0;


function setup() {
  createCanvas(600, 600);
  background(176, 199, 163);
  spillertyk = (width / 15) / 1.5;
  player1 = new Spiller1();
  player2 = new Spiller2();


}



function draw() {
  background(70);




  player1.show();
  player1.update();

  player2.show();
  player2.update();


  //SPILLER_DØR___________________________________________________________________

  if (liv1 === 3 && liv2 === 3) {
    fill(133, 41, 41);
    rect(0, 0, width, height);
    fill(179, 179, 179);
    rect(width / 3 * 0.5, width / 3, width / 3 * 2, width / 3);
    textSize(55);
    stroke(255);
    fill(255);
    strokeWeight(2);
    text('DRAW', width / 2 - 100, width / 3 + 120);
    textSize(27);
    text('Tryk  r  for at prøve igen',width/2-185,height/3+185);
  } else if (liv1 === 3) {
    fill(133, 41, 41);
    rect(0, 0, width, height);
    fill(179, 179, 179);
    rect(width / 3 * 0.5, width / 3, width / 3 * 2, width / 3);
    textSize(55);
    stroke(255);
    fill(255);
    strokeWeight(2);
    text('PLAYER 2 WIN', width / 2 - 185, width / 3 + 120);
    textSize(27);
    text('Tryk  r  for at prøve igen',width/2-185,height/3+185);
  } else if (liv2 === 3) {
    fill(133, 41, 41);
    rect(0, 0, width, height);
    fill(179, 179, 179);
    rect(width/3 * 0.5, width/3, width/3 * 2, width/3);
    textSize(55);
    stroke(255);
    fill(255);
    strokeWeight(2);
    text('PLAYER 1 WIN', width / 2 - 185, width / 3 + 120);
    textSize(27);
    text('Tryk  r  for at prøve igen',width/2-185,height/3+185);
  }

  //START_KNAP____________________________________________________________________

  if (start === 0) {
    stroke(255);
    strokeWeight(3);
    fill(133, 41, 41);
    rect(0, 0, width, height);
    fill(179, 179, 179);
    rect(width / 3 * 0.5, width / 3, width / 3 * 2, width / 3);
    textSize(55);
    stroke(255);
    fill(255);
    strokeWeight(4);
    text('START', width / 2 - 100, width / 3 + 120);

  }
}

function keyPressed() {
  if (key === 'r') {
    liv1=0;
    liv2=0;
    clear();
  }
}
  

function mouseClicked() {

  if (mouseClicked) {
    start = 1;
  }
}